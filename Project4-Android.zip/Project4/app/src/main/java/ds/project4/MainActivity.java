/**
 * Author : KuanMing Hou
 * AndrewID : kuanminh
 */

package ds.project4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    EditText monthInput, yearInput;
    Button fetchButton;
    TextView resultText;

    String servletUrl = "https://humble-orbit-55g59w954pw3pg9g-8080.app.github.dev/employment";  // ✅ Replace this with your Codespace URL

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        monthInput = findViewById(R.id.monthInput);
        yearInput = findViewById(R.id.yearInput);
        fetchButton = findViewById(R.id.fetchButton);
        resultText = findViewById(R.id.resultText);

        fetchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String month = monthInput.getText().toString().trim();
                String year = yearInput.getText().toString().trim();

                String queryUrl = servletUrl + "?month=" + month + "&year=" + year;

                resultText.setText("Fetching...");

                new Thread(() -> {
                    try {
                        URL url = new URL(queryUrl);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("GET");

                        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = in.readLine()) != null) {
                            response.append(line);
                        }
                        in.close();

                        JSONObject json = new JSONObject(response.toString());
                        String yearResponse = json.getString("year");
                        String monthResponse = json.getString("month");
                        String unemployment = json.getString("unemployment");

                        String result = "Unemployment Rate in " + monthResponse + " " + yearResponse + " is: " + unemployment + "%";

                        new Handler(Looper.getMainLooper()).post(() ->
                                resultText.setText(result)
                        );

                    } catch (Exception e) {
                        e.printStackTrace();
                        new Handler(Looper.getMainLooper()).post(() ->
                                resultText.setText("Error: " + e.getMessage())
                        );
                    }
                }).start();
            }
        });
    }
}
