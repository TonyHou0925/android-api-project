/**
 * Author : KuanMing Hou
 * AndrewID : kuanminh
 */

package ds;

import com.mongodb.client.*;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;

import jakarta.servlet.http.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;

public class EmploymentServlet extends HttpServlet {

    private static final String MONGO_URI = "mongodb+srv://kuanminh:b04701130@95702-project4.6brvh.mongodb.net/?retryWrites=true&w=majority&appName=95702-Project4";
    private static final String BLS_API_KEY = "15dcbefa85fb47b5a3fa7678a1172237";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // Get query params
        String month = req.getParameter("month");
        String year = req.getParameter("year");
        String unemploymentValue = null;

        if (month == null || year == null ) {
            resp.setStatus(400);
            resp.getWriter().println("{\"error\": \"Missing required parameters\"}");
            return;
        }

        String seriesID = "LNS14000000";
        String blsRequest = String.format(
                "{\"seriesid\": [\"%s\"], \"month\": \"%s\", \"year\": \"%s\", \"registrationKey\": \"%s\"}",
                seriesID, month, year, BLS_API_KEY);

        String apiResponse = "";
        JSONObject resultJson = new JSONObject();
        boolean success = false;

        try {
            // Call BLS API
            URL url = new URL("https://api.bls.gov/publicAPI/v2/timeseries/data/");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            os.write(blsRequest.getBytes());
            os.flush();
            os.close();

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                sb.append(inputLine);
            }
            in.close();

            apiResponse = sb.toString();
            JSONObject json = new JSONObject(apiResponse);
            JSONArray seriesArray = json.getJSONObject("Results").getJSONArray("series");
            JSONArray dataArray = seriesArray.getJSONObject(0).getJSONArray("data");
            JSONObject matched = null;

            for (int i = 0; i < dataArray.length(); i++) {
                JSONObject item = dataArray.getJSONObject(i);
                if (item.getString("year").equals(year) && item.getString("period").equals(String.format("M%02d", Integer.parseInt(month)))) {
                    matched = item;
                    break;
                }
            }

            if (matched != null) {
                unemploymentValue = matched.getString("value");

                resultJson.put("year", matched.getString("year"));
                resultJson.put("month", matched.getString("periodName"));
                resultJson.put("unemployment", unemploymentValue);
                success = true;
            } else {
                resultJson.put("error", "No matching data found.");
            }

        } catch (Exception e) {
            resultJson.put("error", "Failed to fetch or parse data");
        }

        // Log to MongoDB
        try (MongoClient mongoClient = MongoClients.create(MONGO_URI)) {
            MongoDatabase database = mongoClient.getDatabase("employment_app");
            MongoCollection<Document> collection = database.getCollection("logs");

            Document logEntry = new Document()
                    .append("timestamp", Instant.now().toString())
                    .append("month", month)
                    .append("year", year)
                    .append("blsRequest", blsRequest)
                    .append("blsResponse", apiResponse)
                    .append("unemployment", unemploymentValue)
                    .append("success", success);

            collection.insertOne(logEntry);
        }

        // Return to mobile client
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(resultJson.toString());
    }
}

