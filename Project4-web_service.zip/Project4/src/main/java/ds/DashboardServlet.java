/**
 * Author : KuanMing Hou
 * AndrewID : kuanminh
 */

package ds;

import com.mongodb.client.*;
import org.bson.Document;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class DashboardServlet extends HttpServlet {

    private static final String MONGO_URI = "mongodb+srv://kuanminh:b04701130@95702-project4.6brvh.mongodb.net/?retryWrites=true&w=majority&appName=95702-Project4";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        try (MongoClient mongoClient = MongoClients.create(MONGO_URI)) {
            MongoDatabase database = mongoClient.getDatabase("employment_app");
            MongoCollection<Document> logsCollection = database.getCollection("logs");

            List<Document> logs = logsCollection.find().into(new ArrayList<>());
            req.setAttribute("logs", logs);

            long total = logs.size();
            long successCount = logs.stream().filter(d -> d.getBoolean("success", false)).count();
            double successRate = total > 0 ? (successCount * 100.0 / total) : 0.0;
            req.setAttribute("successRate", successRate);

            List<Double> rates = new ArrayList<>();
            Map<String, Double> rateSeries = new TreeMap<>();

            for (Document doc : logs) {
                if (doc.getBoolean("success", false) && doc.containsKey("unemployment")) {
                    try {
                        double value = Double.parseDouble(doc.getString("unemployment"));
                        String year = doc.getString("year");
                        String month = doc.getString("month");

                        int monthInt = Integer.parseInt(month);
                        String label = String.format("%04d-%02d", Integer.parseInt(year), monthInt);

                        rates.add(value);
                        rateSeries.put(label, value);
                    } catch (Exception ignored) {}
                }
            }

            double avgRate = rates.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
            req.setAttribute("averageRate", avgRate);
            req.setAttribute("rateSeries", rateSeries);

            RequestDispatcher dispatcher = req.getRequestDispatcher("/dashboard.jsp");
            dispatcher.forward(req, resp);
        }
    }
}


